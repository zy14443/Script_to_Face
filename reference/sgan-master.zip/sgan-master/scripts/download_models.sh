wget -O models.zip 'https://www.dropbox.com/s/h8q5z4axfgzx9eb/models.zip?dl=0'
unzip -q models.zip
rm -rf models.zip
